/* Research-only, passive actual logical frame prelude and its nested IRQs. */
#include "battle-world-dma-observer.c"
static uint8_t frame_snapshots[2][65536];
static unsigned frame_reserved_carry;
static void frame_snapshot(unsigned which){for(unsigned i=0;i<65536;i++)frame_snapshots[which][i]=ram[i^1];}
void world_frame_prefix_begin(void){battle_prefix_begin();observing=1;frame_reserved_carry=0;}
void world_frame_prefix_hook(int type,int width,unsigned address,unsigned value){unsigned p=address&0xffffff;if(type==1){last_pc=p;if(!active&&!done&&p==0x3a2e){frame_snapshot(0);frame_reserved_carry=(get(1)>>8)&15;active=1;dma_put(9,p,0,0,0);}if(active){if(p==0x3a5a||p==0x200){frame_snapshot(1);dma_put(10,p,0,0,0);active=0;done=1;}else dma_put(1,p,0,0,0);}}else if(active&&(type==2||type==4)){if((p>=0xc00000&&p<0xe00000)||(p&0xffff00)==0xa11100||p==0xa01fff)dma_put((unsigned)type,last_pc,(unsigned)width,p,value);}}
const uint8_t*world_frame_prefix_snapshot(unsigned which){return frame_snapshots[which&1];}
unsigned world_frame_prefix_carry(void){return frame_reserved_carry;}
